import java.util.Scanner;

public class MainClass
{
	public static void main(String []args)
	{
		/*TestMainMyPoint t = new TestMainMyPoint();
		t.iterateP();
		t.pointCh();*/
		Initialize l = new Initialize();
		l.iterateP();
		l.pointCh();		
	}
}
