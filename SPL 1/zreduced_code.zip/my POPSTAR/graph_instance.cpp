/**************************************************************
 * 
 * class PMGraphInstance: 
 * 
 **************************************************************/

#include "basics.h"
#include "distance.h"
#include "bossa_timer.h"
#include "graph_instance.h"
#include <string.h>

/******************************************
 *
 * constructor: produces an empty instance
 * 
 ******************************************/

PMGraphInstance::PMGraphInstance():PMMatrixInstance() {
	floyd_time = 0.0;
	graph = NULL;
}


/**************************************************************
 *
 * floyd(): Floyd's algorithm to calculate all distances
 *          assumes array already initialized with infinity in
 *          all positions for which the distance is unknown;
 * this function assumes that n=m (all cities are potential
 * facilities)
 *
 **************************************************************/



/************************************************
 * 
 * fatal: prints error message and exits program
 *
 ************************************************/

void PMGraphInstance::fatal (const char *func, const char *msg) {
	fprintf (stderr, "PMGraphInstance::%s: %s.\n", func, msg);
	exit(-1);
}

/*******************************************************
 * 
 * readDimacs: reads file in Dimacs format and executes
 *             Floyd's algorithm to compute the full
 *             distance matrix
 *
 *******************************************************/
/* MODIFIED BY SERGIO GARCIA TO READ A DIFFERENT (REDUCED) FORMAT
   FOR P-MEDIAN PROBLEM 24/11/2008 */

void PMGraphInstance::readDimacs (FILE *input,const char *input_name) {
	fscanf_s(input,"%i",&n);
	m = n;
	fscanf_s(input,"%i",&p);
	d = new int* [n+1]; 
	for(int i=0;i<=n;i++) d[i] = new int[m+1];
	for(int i=1;i<n;i++)
	{			
		for(int j=i+1;j<=n;j++)
		{
			fscanf_s(input,"%i",&d[i][j]);
			d[j][i] = d[i][j];
		}
		d[i][i] = 0;
	}
	
	initOracle();
}




/***********************************************
 *
 * destructor: deallocates vectors and arrays
 *
 ***********************************************/
PMGraphInstance::~PMGraphInstance() {delete graph;};

