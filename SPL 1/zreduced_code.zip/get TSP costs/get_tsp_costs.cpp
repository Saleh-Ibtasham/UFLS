#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <ctime>
using namespace std;

char *input_file_name,*output_file_name;
const char *data_mode;
FILE *input_file,*output_file;
int nodes,p;
vector<double> x;
vector<double> y;

clock_t t1;

void Read_Data()
{
	int nada;
	
	fscanf_s(input_file,"%i",&nodes);
	
	x.resize(nodes);
	y.resize(nodes);

	for(int i=0;i<nodes;i++)
	{
		fscanf_s(input_file,"%i %lf %lf",&nada,&x[i],&y[i]);
	}
	return;
}

void Write_Data()
{
	int open_status;
	if (output_file_name == NULL)
    {
      printf("The file %s could not be created. \n",output_file_name);
      exit(1);
    }
	
	open_status = fopen_s(&output_file,output_file_name,"w");
	if (open_status!=0)
	{
		printf("The file %s could not be opened for writing",output_file_name);
	}
	t1 = clock();
	fprintf(output_file,"%i\n",nodes);
	fprintf(output_file,"%i\n",(int)nodes/10);
	double aux;
	if (data_mode[0]=='r')
	{
		for(int i=0;i<nodes;i++)
		{
			for(int j=i+1;j<nodes;j++)
			{
				aux = sqrt(pow(x[i]-x[j],2)+pow(y[i]-y[j],2));
				fprintf(output_file,"%lf ",aux);
			}
		}		
	}
	else
	{
		for(int i=0;i<nodes;i++)
		{
			for(int j=i+1;j<nodes;j++)
			{
				aux = sqrt(pow(x[i]-x[j],2)+pow(y[i]-y[j],2));
				fprintf(output_file,"%i ",(int)aux);
			}
			fprintf(output_file,"\n");
		}
	}
	fprintf(output_file,"Create data time: %lf\n",(double)(clock()-t1)/CLOCKS_PER_SEC);
	fclose(output_file);
}


int main(int argc,char *argv[])
{
	int open_status;
	if (argc!=4)
    {
      printf("Wrong number of arguments.\n");
      printf("The right way is:\n");
      printf("TSP_costs input-file output-file casting\n");
	  printf("Data mode 'r' for real numbers or 'i' for int numbers (store mode)\n");
      exit(1);
    }

	input_file_name=argv[1];
	output_file_name=argv[2];
	
	string aux = argv[3];
	data_mode = aux.c_str();
	
	if ( (data_mode[0]!='r') && (data_mode[0]!='i') )
	{
		printf("Wrong data-mode. It must be 'i' or 'r'.\n");
		exit(1);
	}
	
	open_status = fopen_s(&input_file,input_file_name,"r");
	if (open_status!=0)
	{
		printf("The file %s could not be opened for reading.\n",input_file);
		exit(1);
	}
	Read_Data();
	fclose(input_file);
	Write_Data();
}