#include <stdlib.h>
#include <algorithm>

bool Read_Parameters(int argc,char *argv[])
{
	if(argc<2) return false;
	char *file_name;
	file_name = argv[1];
	if (strlen(file_name)>=5)
	{
		if(strcmp(&file_name[strlen(file_name)-4], ".tsp") == 0) data_format=1;
		else if(strcmp(&file_name[strlen(file_name)-7], ".dimacs") == 0)
		{
			data_format=2;
		}
		else
		{
			printf("ERROR: data extension not recognized.\n");
			printf("Valid extensions: .tsp, .dimacs\n");
			return false;
		}
	}
	int arg = 2;
	while(arg<argc)
	{
		if(strcmp(arg[argv],"-p")==0)
		{
			++arg;
			if(arg==argc) return false;
			p = atoi(argv[arg]);
			if(p<=0)
			{
				printf("ERROR: p must be strictly positive.\n");
				return false;
			}
			no_p = false;
			++arg;
			continue;
		}

		if(strcmp(arg[argv],"-b")==0)
		{
			++arg;
			if(arg==argc) return false;
			incumbent_value = atof(argv[arg]);
			++arg;
			continue;
		}

		if(strcmp(arg[argv],"-h")==0)
		{
			RW = true;
			++arg;
			if(arg==argc) return false;
			RWiter = atoi(argv[arg]);
			++arg;
			continue;
		}

		if(strcmp(arg[argv],"-s")==0)
		{
			save_solution_info = true;
			++arg;
			if(arg==argc) return false;
			solution_file_name= argv[arg];
			++arg;
			continue;
		}

		if(strcmp(arg[argv],"-d")==0)
		{
			++arg;
			if(arg==argc) return false;
			int d = atoi(argv[arg]);
			if(d==1) allD = true;
			else if(d!=0) return false;
			++arg;
			continue;
		}

		return false;
	}

	if(no_p)
	{
		printf("ERROR: No value for p has been given.\n");
		return false;
	}
	return true;
}

int ctsp(int i,int j)
{
	double a = x[i] - x[j];
	double b = y[i] - y[j];
	a *= a;
	b *= b;
	return (int)sqrt(a+b);	
}

int cdimacs(int i,int j)
{
	if(i<j) return cost[i][j-i-1];
	if(i>j) return cost[j][i-j-1];
	return 0;
}

int D(int i,int k)
{
	if (k<Dv[i].size()) return Dv[i][k];
	else
	{
		int aux,aux2;
		int bestval = intM;
		aux2 = Dv[i][k-1];
		if(data_format==1)
		{
			for(int h=0;h<nodes;h++)
			{
				aux = ctsp(i,h);
				if( (aux<bestval-tolerance) && (aux>aux2+tolerance) )
				{
					bestval = aux;
					if(aux==aux2+1) break;
				}
			}
		}
		else
		{
			for(int h=0;h<nodes;h++)
			{
				aux = cdimacs(i,h);
				if( (aux<bestval-tolerance) && (aux>aux2+tolerance) )
				{
					bestval = aux;
					if(aux==aux2+1) break;
				}
			}
		}
		Dv[i].push_back(bestval);
		return bestval;
	}
}

/* Read the initial data: nodes, p, cost[i][j] */
int Read_Data(char *file_name)
{
	FILE *data_file;
	if(fopen_s(&data_file,file_name,"r")) return 0;
	
	const int LINESIZE = 256;
	char buffer [LINESIZE + 1];
	if (data_format==1)
	{
		fprintf (stderr,"Reading TSP instance... ");
		double vx, vy;
		int v;
		bool size_read = false;
		while (fgets (buffer, LINESIZE, data_file))
		{
			if (sscanf_s(buffer, "DIMENSION : %d", &nodes) == 1) 
			{
				size_read = true;
				x = new double[nodes]; 
				y = new double[nodes];
				continue;
			}
			if (sscanf_s(buffer, "%d %lg %lg", &v, &vx, &vy) == 3)
			{
				if (!size_read) 
				{
					printf("ERROR: wrong data structure in file %s\n",file_name);
					return 0;
				}
				x[v-1] = vx;
				y[v-1] = vy;
				continue;
			}
		}
	}
	else
	{
		fprintf (stderr,"Reading DIMACS instance... ");
		fscanf_s(data_file,"%i",&nodes);
		int pp;
		fscanf_s(data_file,"%i",&pp);
		
		try{
			cost.resize(nodes-1);	
			for(int i=0;i<nodes-1;i++)
			{
				cost[i].resize(nodes-1-i);
				for(int j=i+1;j<nodes;j++)
				{
					fscanf_s(data_file,"%i",&cost[i][j-i-1]);
				}
			}
			while (fgets (buffer, LINESIZE, data_file))
			{
				if (sscanf_s(buffer, "Create data time: %lf", &external_generation_time) == 1)
				{
					break;
				}
			}
		}
		catch(const bad_alloc)
		{
			cout << "ERROR: out of memory while reading costs." << endl;
			return 0;
		}
	}
	fprintf (stderr, "done.\n");
	fclose(data_file);
	return 1;
}

bool my_order_criterion (int i,int j)
{
	return (i<j);
}

/* Sort an array v from the least value to the largest one */
/* Remove repeated elements */
/* Return since of this new without-multiplicties vector */
int Sort_Int_Array(vector<int> &v)
{
	/* Sort vector */
	sort(v.begin(),v.end(),my_order_criterion);	
	/* Remove p-1 largest costs */
	v.erase(v.end()-p+1,v.end());
	/* Remove repeated elements */
	vector<int>::iterator temp_iterator;
	temp_iterator = v.begin();
	while(temp_iterator!=(v.end()-1))
	{
		if (abs(*temp_iterator-*(temp_iterator+1))<tolerance)
		{
			v.erase(temp_iterator+1);
		}
		else ++temp_iterator;
	}
	v.push_back(intM);
	return v.size();
}

void Generate_D_sdznoh()
{
	// Generate D
	// Generate sdz without starting heuristic information
	G = new int[nodes];
	/* Sort costs increasingly and without multiplicties */
	Dv.resize(nodes);
	int min_G = nodes;
	vector<int> aux;
	double sdzf;
	if(allD)
	{
		if(data_format==1)
		{
			for(int i=0;i<nodes;i++)
			{
				aux.resize(nodes);
				for(int j=0;j<nodes;j++) aux[j] = ctsp(i,j);
				// We substract one because of the artificial largest cost
				G[i] = Sort_Int_Array(aux) -1;
				if(G[i]<min_G) min_G = G[i];
				Dv[i] = aux;
				aux.~vector();
			}
		}
		else
		{
			for(int i=0;i<nodes;i++)
			{
				aux.resize(nodes);
				for(int j=0;j<nodes;j++) aux[j] = cdimacs(i,j);
				// We substrct one because of the artificial largest cost
				G[i] = Sort_Int_Array(aux) - 1;
				if(G[i]<min_G) min_G = G[i];
				Dv[i] = aux;
				aux.~vector();
			}
		}
		int totalG; //totalG[i] = G[0] + ... + G[i]
		totalG = G[0];
		for(int i=1;i<nodes;i++) totalG+= G[i];
		sdzf = (totalG/nodes)/p;
	}
	else
	{
		for(int i=0;i<nodes;i++)
		{
			Dv[i].resize(1);
			Dv[i][0] = 0;
			G[i] = nodes - p + 1; // Artificial upper bound. 
		}
		// Estimate sdz
		// Let u = ceil(alpha*nodes), 0 < alpha <= 1.
		// Select nodes floor(h*(nodes-1)/u), h=0,1,2,...,u.
		
		int partialG = 0;
		int samplesize = (int)ceil((double)alpha*nodes);
		int Gi,k;
		for(int h=0;h<=samplesize;h++)
		{
			k = (int)floor((double)h*(nodes-1)/samplesize);
			aux.resize(nodes);
			if(data_format==1)
			{
				for(int j=0;j<nodes;j++) aux[j] = ctsp(k,j);
			}
			else
			{
				for(int j=0;j<nodes;j++) aux[j] = cdimacs(k,j);
			}
			// We substrct one because of the artificial largest cost
			Gi= Sort_Int_Array(aux) - 1;
			partialG+= Gi;
			if(Gi<min_G) min_G = Gi;
			aux.~vector();
		}
		sdzf = partialG/((1+samplesize)*p);
	}
	if(sdzf>min_G) sdzf = min_G;
	// Reduce sdzf if the initial number of constraints is large 
	double auxf = (sdzf-2)*nodes;
	if(auxf<10000) sdzf*= 2;
	else sdzf*= log10(1000.0)/log10(auxf);
	
	sdz = (int)ceil(sdzf);
	if(sdz<3) sdz=3;
	sdz-= 2;
	printf("SDZ: %i\n",sdz);
	ind_sdz.resize(nodes);
	for(int i=0;i<nodes;i++) ind_sdz[i] = sdz;
	return;
}

void Generate_D_sdzh()
{
	// Generate D
	// Generate sdz with starting heuristic information
	
	/* Sort costs increasingly and without multiplicties */
	Dv.resize(nodes);
	vector<int> aux;
	if(allD)
	{
		if(data_format==1)
		{
			for(int i=0;i<nodes;i++)
			{
				aux.resize(nodes);
				for(int j=0;j<nodes;j++) aux[j] = ctsp(i,j);
				Sort_Int_Array(aux);
				Dv[i] = aux;
				aux.~vector();
			}
		}
		else
		{
			for(int i=0;i<nodes;i++)
			{
				aux.resize(nodes);
				for(int j=0;j<nodes;j++) aux[j] = cdimacs(i,j);
				Sort_Int_Array(aux);
				Dv[i] = aux;
				aux.~vector();
			}
		}
	}
	else
	{
		for(int i=0;i<nodes;i++)
		{
			Dv[i].resize(1);
			Dv[i][0] = 0;
		}
	}
	
	// Get depths from the heuristic solution
	double refv;
	int k;
	ind_sdz.resize(nodes);
	int totz;
	totz = 0;

	if(data_format==1)
	{
		for(int i=0;i<nodes;i++)
		{
			refv = ctsp(i,incumbent_x[i]);
			k = 1;
			while(D(i,k)<refv+tolerance) ++k;
			ind_sdz[i] = k;
			totz+= ind_sdz[i];
		}
	}
	else
	{
		for(int i=0;i<nodes;i++)
		{
			refv = cdimacs(i,incumbent_x[i]);
			k = 1;
			while(D(i,k)<refv+tolerance) ++k;
			ind_sdz[i] = k;
			totz+= ind_sdz[i];
		}
		
	}
	sdz = (int)ceil((double)totz/nodes);
	if(sdz<2) sdz=2;
	//sdz-= 2;
	sdz= (int)(1.1*sdz);
	printf("SDZ: %i\n",sdz);
	for(int i=0;i<nodes;i++)  ind_sdz[i] = sdz;
	return;
}

void Start_S()
{
	S.resize(nodes);
	for(int i=0;i<nodes;i++)
	{
		S[i].resize(1);
		S[i][0].push_back(i);
	}
	return;
}

void myprintf(char *v,int i1,int i2,int i3)
{
	if(save_solution_info) fprintf(solution_file,v,i1,i2,i3);
	else printf(v,i1,i2,i3);
	return;
}

void myprintf(char *v)
{
	if(save_solution_info) fprintf(solution_file,v);
	else printf(v);
	return;
}

void myprintf(char *v1, char *v2)
{
	if(save_solution_info) fprintf(solution_file,v1,v2);
	else printf(v1,v2);
	return;
}

void myprintf(char *v, double d)
{
	if(save_solution_info) fprintf(solution_file,v,d);
	else printf(v,d);
	return;
}

void myprintf(char *v, int i)
{
	if(save_solution_info) fprintf(solution_file,v,i);
	else printf(v,i);
	return;
}

void myprintf(char *v,int i1, int i2)
{
	if(save_solution_info) fprintf(solution_file,v,i1,i2);
	else printf(v,i1,i2);
	return;
}

void myprintf(char *v,double i1, double i2)
{
	if(save_solution_info) fprintf(solution_file,v,i1,i2);
	else printf(v,i1,i2);
	return;
}

void Show_Partial_Solution(void)
{
	myprintf("Total running time: %.0lf\n",(double)(clock()- start_time)/CLOCKS_PER_SEC);
	myprintf("Best lower bound: %lf\n",bestLB);
	if(incumbent_value<IloInfinity)
	{
		myprintf("Best upper bound: %lf\n",incumbent_value);
		if(bestLB>tolerance) myprintf("Gap: %.4lf%%\n",100*(incumbent_value/bestLB-1));
	}
	else myprintf("Best upper bound: none\n");
	myprintf("SDZ: %i\n",sdz);
	return;
}

void Generate_S(int i,int k)
{
	/*Generate S[i][k] */
	try{
		S[i].resize(k+1);
		int val = D(i,k);
		if(data_format==1)
		{
			for(int j=0;j<nodes;j++)
			{
				if(abs(ctsp(i,j)-val)<tolerance) S[i][k].push_back(j);
			}
		}
		else
		{
			for(int j=0;j<nodes;j++)
			{
				if(abs(cdimacs(i,j)-val)<tolerance) S[i][k].push_back(j);
			}
		}
		return;
	}
	catch(const bad_alloc)
	{
		cout << "ERROR: out of memory while constructing S." << endl;
		Show_Partial_Solution();
		exit(1);
	}
}

i_l *Create_i_l(void)
{
	try
	{
		return new i_l;
	}
	catch(const bad_alloc)
	{
		cout << "ERROR: out of memory while adding new rows." << endl;
		Show_Partial_Solution();
		exit(1);
	}
}

n_i *Create_n_i(void)
{
	try
	{
		return new n_i;
	}
	catch(const bad_alloc)
	{
		cout << "ERROR: out of memory while generating node info." << endl;
		Show_Partial_Solution();
		exit(1);
	}
}

a_n *Create_a_n(void)
{
	try
	{
		return new a_n;
	}
	catch(const bad_alloc)
	{
		cout << "ERROR: out of memory while generating node info." << endl;
		Show_Partial_Solution();
		exit(1);
	}
}

