void Solve_Root_Node()
{
	IloEnv env;
	try{
		IloModel model(env);
		clock_t auxi_time;
		vector<int>::iterator v,v2;
		/*1) CREATE THE MODEL */

		/*1.1) Create variables */
		auxi_time = clock();
		IloNumVarArray2 z(env,nodes);
		for(int i=0;i<nodes;i++)
		{
			/* z(i,k) is defined in the model for k=3,...,G[i].
			   In C++, this means k=0,1,...,G[i]-3.
			   Since z(i,1)=1, these variables are not defined.
			   Notice that z(i,2)=1-y(i). Thus variables z(i,2) are not defined.
			   We start with z(i,3).
			   Therefore, z(i,k) = z[i][k-3]. */
			z[i] = IloNumVarArray(env,ind_sdz[i]);
			for(int j=0;j<ind_sdz[i];j++)
			{
				z[i][j] = IloNumVar(env,0,IloInfinity,ILOFLOAT,Get_z_Name(i,j));
			}
		}
		IloNumVarArray y(env,nodes);
		for(int i=0;i<nodes;i++)
		{
			y[i] = IloNumVar(env,0,1,ILOFLOAT,Get_y_Name(i));
		}
		
		/*1.2) Define objective function */
		IloExpr obj_function(env);
		for(int i=0;i<nodes;i++)
		{
			obj_function+= D(i,1)*(1-y[i]);
			for(int k=0;k<ind_sdz[i];k++)
			{
				obj_function+= (D(i,k+2)-D(i,k+1))*z[i][k];
			}
		}
		IloObjective obj(env,obj_function,IloObjective::Minimize);
		obj_function.end();
		model.add(obj);

		/*1.3) State constraints */
		IloExpr aux(env),aux2(env),aux3(env),aux4(env);
		IloRangeArray zconst(env);
		for(int i=0;i<nodes;i++)
		{
			aux+= y[i];
			aux3 = y[i];
			for(int k=0;k<ind_sdz[i];k++)
			{
				Generate_S(i,k+1);
				aux2 = z[i][k];
				v = S[i][k+1].begin();
				v2 = S[i][k+1].end();
				while(v!=v2)
				{
					aux3+= y[*v];
					++v;
				}
				aux4+= aux3;
				aux3.clear();
				aux2+= aux4;
				zconst.add(IloRange(env,1,aux2,IloInfinity,Get_c_Name(i,k)));
				//model.add(IloRange(env,1,aux2,IloInfinity,Get_c_Name(i,k)));
			}
			aux4.clear();
		}
		aux2.end();
		aux3.end();
		aux4.end();
		zconst.add(IloRange(env,p,aux,p,"pc"));
		//model.add(IloRange(env,p,aux,p,"pc"));
		model.add(zconst);
		aux.end();
		generate_model_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;
		printf("Generate starting model time: %lf\n",generate_model_time);
		
		/* SOLVE THE MODEL */
		IloCplex cplex(model);
		Set_Solver_Parameters(cplex);
		cplex.setOut(env.getNullStream());
				
		bool new_z_rows; 
		IloNum obj_value;

		do		
		{
			new_z_rows = false;
			/* Solve formulation */
			auxi_time = clock();
			cplex.solve();
			solve_model_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;
			obj_value = cplex.getObjValue();
			//printf("VV %lf\n",obj_value);
			bestLB = ceil(obj_value);
			if (bestLB>incumbent_value-tolerance)
			{
				LB_root = (int)bestLB;
				env.end();
				return;
			}

			/* Check infeasibilities */
			auxi_time = clock();
			// Get list of z[i][last_k]>0
			int first_i=0;
			i_l *k_list=NULL;
			i_l *first_in_k_list;
			while(first_i<nodes) 
			{
				if(cplex.getValue(z[first_i][z[first_i].getSize()-1])>tolerance)
				{
					k_list = Create_i_l();
					k_list->i = first_i;
					k_list->next = NULL;
					first_in_k_list = k_list;
					new_z_rows = true;
					break;
				}
				++first_i;
			}
			if(new_z_rows)
			{
				++first_i;
				while(first_i<nodes)
				{
					if(cplex.getValue(z[first_i][z[first_i].getSize()-1])>tolerance)
					{
						k_list->next = Create_i_l();
						k_list = k_list->next;
						k_list->i = first_i;
					}
					++first_i;
				}
				k_list->next=NULL;
								
				// Add new inequalities
				int k,the_i;
				k_list = first_in_k_list;
				IloExpr aux4(env);
				while(first_in_k_list!=NULL)
				{
					the_i = first_in_k_list->i;
					k = z[the_i].getSize();
					z[the_i].add(1,IloNumVar(env));
					z[the_i][k] = IloNumVar(env,0,IloInfinity,ILOFLOAT,Get_z_Name(the_i,k));
					aux4 = z[the_i][k];
					Generate_S(the_i,k+1);
					for(int h=0;h<=k+1;h++)
					{						
						v = S[the_i][h].begin();
						v2 = S[the_i][h].end();
						while(v!=v2)
						{
							aux4+= y[*v];
							++v;
						}
					}
					zconst.add(IloRange(env,1,aux4,IloInfinity,Get_c_Name(the_i,k)));
					model.add(zconst[zconst.getSize()-1]);
					//model.add(IloRange(env,1,aux4,IloInfinity,Get_c_Name(the_i,k)));
					obj.setLinearCoef(z[the_i][k],D(the_i,k+2)-D(the_i,k+1));
					first_in_k_list = first_in_k_list->next;
				}
				aux4.end();
				
				// Delete the pointer list
				first_in_k_list = k_list;
				while(first_in_k_list->next!=NULL)
				{
					k_list = first_in_k_list;
					first_in_k_list = first_in_k_list->next;
					k_list->next = NULL;
					delete k_list;
				}
				delete first_in_k_list;
			}
			add_constraints_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;
		}
		while(new_z_rows);
			
		/* If we stop adding additional constraints,
		   then the sum of z infeasibilities is zero.
		   It must be checked if the solution (y array) is integer */
		IloNumArray y_value(env,nodes);
		cplex.getValues(y_value,y);
		if (Check_Integer_y(y_value))
		{
			active_nodes = 0;
			incumbent_value = obj_value;
			incumbentis = true;
			int k=0;
			for(int i=0;i<nodes;i++)
			{
				if(y_value[i]>1-tolerance)
				{
					incumbent_y[k] = i;
					++k;
					incumbent_x[i] = i;
				}
				else
				{
					int r = 0;
					while(cplex.getValue(z[i][r])>tolerance) ++r;
					incumbent_x[i] = S[i][r+1][0];
				}
			}
			LB_root = bestLB;
			env.end();
			return;
		}
		
		/* The root relaxation gives fractional y */
		cplex.writeBasis("1.bas");
		/*3) CHOOSE BRANCHING VARIABLE */
		
		// Parameters for reliability branching
		//reliab = (int)pow(floor(log10((double)nodes)),2);
		reliab = (int)pow(log10((double)nodes),2);
		lambda0 = (int)ceil((double)reliab/2);
		lambda = lambda0;
		lambdamin = (int)floor((double)lambda0/2);
		if(lambdamin==0) lambdamin = 1;
		lambdamax = 2*lambda0;

		/* GENERATE THE FIRST ACTIVE NODE */
		active_nodes = 1;
		n_i *this_node;
		this_node = Create_n_i();
		this_node->parent_node = NULL;
		this_node->active_children = 2;
		this_node->where_zdepths = Enlarge_zdepths(z);
				
		auxi_time = clock();
		
		this_active_node = this_node;
		this_active_node->basis = 1;
		totalbasis = 1;
		
		totaldeltar.resize(nodes);
		totaldeltal.resize(nodes);
		nodesr.resize(nodes);
		nodesl.resize(nodes);
		auxi_time = clock();
		this_node->branching_y = ReliabilityChooseBranchingy(y,zconst,cplex,obj_value,true);
		this_node->y_value = y_value[this_node->branching_y];
		choose_y+= (double)(clock()-auxi_time)/CLOCKS_PER_SEC;
		this_node->lower_bound = obj_value;
		LB_root = bestLB;

		the_first_active_node = Create_a_n();
		the_first_active_node->next = NULL;
		the_first_active_node->previous = NULL;
		the_first_active_node->the_info = this_node;
		
		env.end();
		return;
	}
	catch (IloException& e)
	{
		cerr << "Concert exception caught: " << e << endl;
		myprintf("ERROR: POSSIBLE OUT OF MEMORY CPLEX.\n");
		Show_Partial_Solution();
		CompleteProcesses();
		e.~IloException();
		env.end();
		exit(1);
	}
	catch (...)
	{
		cerr << "Unknown exception caught" << endl;
		myprintf("ERROR: UNKNOWN EXCEPTION\n");
		Show_Partial_Solution();
		CompleteProcesses();
		env.end();
		exit(1);
	}
	env.end();
}
