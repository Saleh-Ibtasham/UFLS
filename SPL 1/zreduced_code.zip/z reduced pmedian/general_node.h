void Solve_General_Node()
{
	/* The advanced basis from the parent node is loaded at the begin of the node.
	   The optimal basis is stored at the end of the node. */

	IloEnv env;
	try{
		IloModel model(env);
		/*1) CREATE THE MODEL */
		clock_t auxi_time,auxi_time2;
		vector<int>::iterator v,v2;
		auxi_time = clock();
		/*1.1) Create variables */
		IloNumVarArray2 z(env,nodes);
		int z_size;
		for(int i=0;i<nodes;i++)
		{
			/* z(i,k) is defined in the model for k=2,3,...,G[i].
			   In C++, this means k=0,2,...,G[i]-2.
			   That is, z(i,k+2) = z[i][k]. */
			// Notice that, since z(i,2)=1-y(i), variables z[i][0] are not used in the model
			//z_size = zdepths[i];
			z_size = zdepths[this_active_node->where_zdepths][i];
			z[i] = IloNumVarArray(env,z_size);
			for(int j=0;j<z_size;j++)
			{
				z[i][j] = IloNumVar(env,0,IloInfinity,ILOFLOAT,Get_z_Name(i,j));	
			}
		}
		IloNumVarArray y(env,nodes);
		for(int i=0;i<nodes;i++)
		{
			y[i] = IloNumVar(env,0,1,ILOFLOAT,Get_y_Name(i));
		}
		
		/*1.2) Define objective function */
		IloExpr obj_function(env);
		for(int i=0;i<nodes;i++)
		{
			obj_function+= D(i,1)*(1-y[i]);
			for(int k=0;k<z[i].getSize();k++)
			{
				obj_function+= (D(i,k+2)-D(i,k+1))*z[i][k];
			}
		}
		IloObjective obj(env,obj_function,IloObjective::Minimize);
		obj_function.end();
		model.add(obj);
				
		/*1.3) State constraints */
		IloExpr aux(env),aux2(env),aux3(env),aux4(env);
		IloRangeArray zconst(env);
		for(int i=0;i<nodes;i++)
		{
			aux+= y[i];
			aux3 = y[i];
			for(int k=0;k<z[i].getSize();k++)
			{
				aux2 = z[i][k];
				v = S[i][k+1].begin();
				v2 = S[i][k+1].end();
				while(v!=v2)
				{
					aux3+= y[*v];
					++v;
				}
				aux4+= aux3;
				aux3.clear();
				aux2+= aux4;
				//model.add(IloRange(env,1,aux2,IloInfinity,Get_c_Name(i,k)));
				zconst.add(IloRange(env,1,aux2,IloInfinity,Get_c_Name(i,k)));
			}
			aux4.clear();
		}
		aux2.end();
		aux3.end();
		aux4.end();
		//model.add(IloRange(env,p,aux,p,"pc"));
		zconst.add(IloRange(env,p,aux,p,"pc"));
		model.add(zconst);
		aux.end();
			
		/*1.4) Add the fixed values constraints */
		n_i *auxni = this_active_node;
		while (auxni->parent_node!=NULL)
		{
			y[auxni->parent_node->branching_y].setBounds(auxni->branch_value,auxni->branch_value);
			auxni = auxni->parent_node;
		}
		generate_model_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;

		/* SOLVE THE MODEL */
		IloCplex cplex(model);
		Set_Solver_Parameters(cplex);
		cplex.setOut(env.getNullStream());	
		
		IloNum obj_value;
		/* Name of the parent node's basis */
		const char *basis_name_parent = Get_Basis_Name(this_active_node->parent_node->basis);
		/* The first basis to be read is the one of the parent node */
		auxi_time=clock();
		cplex.readBasis(basis_name_parent);
		read_basis_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;
		/* Solve formulation */
		auxi_time=clock();
		cplex.solve();
		solve_model_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;
		if (cplex.getStatus()==IloAlgorithm::Infeasible)
		{
			Prune_Node(this_active_node);
			env.end();
			return;
		}
		UpdatePseudocost(this_active_node->parent_node->lower_bound,cplex.getObjValue(),this_active_node->branch_value,this_active_node->parent_node->y_value,this_active_node->parent_node->branching_y);
		bool yes_z_rows = false;
		bool new_z_rows; 
		do
		{
			new_z_rows = false;
			obj_value = cplex.getObjValue();
			if (ceil(obj_value)>incumbent_value-tolerance)
			{
				Prune_Node(this_active_node);
				env.end();
				return;
			}
			
			/* Check infeasibilities */
			auxi_time=clock();
			int first_i=0;
			i_l *k_list=NULL;
			i_l *first_in_k_list;
			while(first_i<nodes) 
			{
				if(cplex.getValue(z[first_i][z[first_i].getSize()-1])>tolerance)
				{
					k_list = Create_i_l();
					k_list->i = first_i;
					k_list->next = NULL;
					first_in_k_list = k_list;
					new_z_rows = true;
					break;
				}
				++first_i;
			}
			if(new_z_rows)
			{
				yes_z_rows = true;
				++first_i;
				while(first_i<nodes)
				{
					if(cplex.getValue(z[first_i][z[first_i].getSize()-1])>tolerance)
					{
						k_list->next = Create_i_l();
						k_list = k_list->next;
						k_list->i = first_i;
					}
					++first_i;
				}
				k_list->next=NULL;
								
				int k,the_i;
				k_list = first_in_k_list;
				IloExpr aux4(env);
				while(first_in_k_list!=NULL)
				{
					the_i = first_in_k_list->i;
					k = z[the_i].getSize();
					z[the_i].add(1,IloNumVar(env));
					z[the_i][k] = IloNumVar(env,0,IloInfinity,ILOFLOAT,Get_z_Name(the_i,k));
					aux4 = z[the_i][k];
					if(S[the_i].size()==k+1) Generate_S(the_i,k+1);
					for(int h=0;h<=k+1;h++)
					{						
						v = S[the_i][h].begin();
						v2 = S[the_i][h].end();
						while(v!=v2)
						{
							aux4+= y[*v];
							++v;
						}
					}
					zconst.add(IloRange(env,1,aux4,IloInfinity,Get_c_Name(the_i,k)));
					model.add(zconst[zconst.getSize()-1]);
					//model.add(IloRange(env,1,aux4,IloInfinity,Get_c_Name(the_i,k)));
					obj.setLinearCoef(z[the_i][k],D(the_i,k+2)-D(the_i,k+1));
					first_in_k_list = first_in_k_list->next;
				}
				aux4.end();
							
				first_in_k_list = k_list;
				while(first_in_k_list->next!=NULL)
				{
					k_list = first_in_k_list;
					first_in_k_list = first_in_k_list->next;
					k_list->next = NULL;
					delete k_list;
				}
				delete first_in_k_list;

				/* Solve formulation */
				auxi_time2=clock();
				cplex.solve();
				solve_model_time+=(double)(clock()-auxi_time2)/CLOCKS_PER_SEC;
				add_constraints_time-=(double)(clock()-auxi_time2)/CLOCKS_PER_SEC;
			}
			add_constraints_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;
		}
		while(new_z_rows);		
		/* If we stop adding additional constraints,
		   then the sum of z infeasibilities is zero. */

		/*   It must be checked if the solution (y array) is integer */
		IloNumArray y_value(env,nodes);
		cplex.getValues(y_value,y);
		if (Check_Integer_y(y_value))
		{
			if(obj_value<incumbent_value-tolerance)
			{
				incumbent_value = obj_value;
				int k=0;
				incumbentis = true;
				for(int i=0;i<nodes;i++)
				{
					if(y_value[i]>1-tolerance)
					{
						incumbent_y[k] = i;
						++k;
						incumbent_x[i] = i;
					}
					else
					{
						int r = 0;
						while(cplex.getValue(z[i][r])>tolerance) ++r;
						incumbent_x[i] = S[i][r+1][0];
					}
				}
			}
			/* Prune by optimality */
			Prune_Node(this_active_node);
			env.end();
			return;
		}
		else
		{
			/* The root relaxation gives fractional y */
			if(yes_z_rows)
			{
				this_active_node->where_zdepths = Enlarge_zdepths(z);
				auxi_time=clock();
				++totalbasis;
				this_active_node->basis = totalbasis;
				cplex.writeBasis(Get_Basis_Name(totalbasis));
				write_basis_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;
			}
			else this_active_node->basis = this_active_node->parent_node->basis;
						
			this_active_node->lower_bound = obj_value;
			this_active_node->active_children = 2;
			auxi_time = clock();
			this_active_node->branching_y = ReliabilityChooseBranchingy(y,zconst,cplex,obj_value,yes_z_rows);
			this_active_node->y_value = y_value[this_active_node->branching_y];
			choose_y+= (double)(clock()-auxi_time)/CLOCKS_PER_SEC;
			Insert_in_List(this_active_node);
			env.end();
			return;
		}
	}
	catch (IloException& e)
	{
		cerr << "Concert exception caught: " << e << endl;
		myprintf("ERROR: POSSIBLE OUT OF MEMORY CPLEX.\n");
		Show_Partial_Solution();
		CompleteProcesses();
		e.~IloException();
		env.end();
		exit(1);
	}
	catch (...)
	{
		cerr << "Unknown exception caught" << endl;
		Show_Partial_Solution();
		CompleteProcesses();
		env.end();
		exit(1);
	}	
	env.end();
}