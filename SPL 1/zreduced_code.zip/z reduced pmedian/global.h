/* This file contains the global variables */
#include <vector>

#define tolerance 1E-6
#define epsilon 1E-3
#define M 1E10
#define intM 99999999
#define time_limit 360000 // 100 hours
#define alpha 0.01
#define mu 0.01 // Weight for the maximum pseudocost

int data_format; // 1 == tsp, 2 == dimacs
double *x,*y;

int sdz;// starting depth for z
vector<int> ind_sdz; //individual sdz values
clock_t start_time;

double generate_model_time; // Time generating the the starting model at the nodes
double solve_model_time; // Time solving the model in the nodes
double write_basis_time; // Time writing basis
double add_constraints_time; // Time adding rows
double read_basis_time; // Time reading basis (strong branching not included)
double choose_y; // Time choosing y
double external_generation_time; // Floyd time for dimacs files
double strongb_readb_time; // Time reading basis in strong branching
double strongb_solve_time; // Time solving auxiliar models in strong branching
double create_data_time;
double root_time;

typedef IloArray<IloNumVarArray> IloNumVarArray2;
typedef vector<vector<int> > intmatrix2;
typedef vector<vector<vector<int> > > intmatrix3;

intmatrix3 S; // S(i,j) = {k / c(i,k) = D(i,j) }
int nodes,p;
intmatrix2 cost; // matrix of costs 

int totalbasis; // Number of stored basis

int reliab,lambda,lambda0,lambdamin,lambdamax; // Parameters for reability branching

int *G; // G[i] = number of diferents cost(i,j), j=1,2,...,nodes.
vector<vector<int> > Dv; // matrix of ordered costs without multiplicities 

int active_nodes; // number of nodes in the list to branch on 
int total_nodes; // number of nodes so far generated 

bool allD = false; // true if all the D are generated at the begin; false if dynamically in the problem solving

IloNum bestLB = -IloInfinity; // Best lower bound
IloNum LB_root; // Lower bound at root node
IloNum incumbent_value = IloInfinity; // Best (feasible) value of the problem up to now 
IloNum initial_upper_bound; // Objective value from the heuristic initial solution
vector<int> incumbent_y;
vector<int> incumbent_x;
bool incumbentis = false; // true if a solution (x,y) is available

bool RW;
int RWiter;
double heur_time;

int totalstrong; // Number of times strong branching is applied (2 problems are solved each time)

bool no_p = true;
bool save_solution_info;
char *solution_file_name;
FILE *solution_file;

intmatrix2 zdepths;

vector<double> totaldeltar,totaldeltal; // Total increments at right and left 
vector<int> nodesr,nodesl; // Number of increments at right and left
vector<int> initpsr,initpsl; // List of initialized pseudocosts at right and left
double avgpsr,avgpsl; // Average right and left pseudocosts

typedef struct n_i
{
	bool branch_value; /* This is the fixed value for the parent's node branching variable */
	/* true = 1, false = 0 */
	short active_children; /* 2 when created, -1 for each son pruned */
	int branching_y; /* Create two children nodes by branching on this variable */
	int where_zdepths;
	int basis;
	double lower_bound;
	double y_value;
	n_i *parent_node;
	n_i *left_son;
	n_i *right_son;
} node_info;

typedef struct a_n
{
	n_i *the_info;
	a_n *previous;
	a_n *next;
} active_node;

a_n *the_first_active_node; /* Points to the first node in the list of actives nodes */
n_i *this_active_node; /* Points to the information of the node being solved */

typedef struct i_l
{
	int i; /* node */
	i_l *next;
} integer_list;

typedef struct s_l
{
	int i;
	double sc;
} score_list;