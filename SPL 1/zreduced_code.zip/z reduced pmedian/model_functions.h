/* Get_Basis_Name(i).c_str() is the name of the file where the basis is saved.
   It must be of the type const char* */
char *Get_Basis_Name(int i)
{
	char aux[13];
	sprintf_s(aux,"%d.bas",i);
	return aux;	
}

char *Get_y_Name(int i)
{
	char aux[8];
	sprintf_s(aux,"y%d",i);
	return aux;	
}

char *Get_z_Name(int i,int j)
{
	char aux[15];
	sprintf_s(aux,"z%d,%d",i,j);
	return aux;
}

char *Get_c_Name(int i,int j)
{
	char aux[15];
	sprintf_s(aux,"c%d.%d",i,j);
	return aux;
}

bool Check_Integer_y(IloNumArray y_value)
{
	int i=0;
	while(i<nodes)
	{
		if ( (y_value[i]>tolerance) && (y_value[i]<1-tolerance) ) return false;
		++i;
	}	
	return true;
}

double Score(double v1, double v2, int mod)
{
	if(mod==1)
	{
		double w1 = v1;
		double w2 = v2;
		if(v1<epsilon) w1 = epsilon;
		if(v2<epsilon) w2 = epsilon;
		return w1*w2;	
	}
	else
	{
		if(v1>v2) return (mu*v1 + (1-mu)*v2);
		return ((1-mu)*v1 + mu*v2);
	}
}

void UpdateAvgPs(void)
{
	double tl,tr;
	tl = tr = 0;
	vector<int>::iterator v1,v2;
	v1 = initpsl.begin();
	v2 = initpsl.end();
	while(v1!=v2)
	{
		tl+= totaldeltal[*v1]/nodesl[*v1];
		tr+= totaldeltar[*v1]/nodesr[*v1];
		++v1;
	}
	avgpsl = tl/initpsl.size();
	avgpsr = tr/initpsr.size();
	return;
}

double PseudocostL(int i)
{
	if(nodesl[i]==0)
	{
		// Uninitialized left pseudocost
		if(initpsl.size()==0)
		{
			// No initialized left pseudocost
			return 1;
		}
		else return avgpsl;
	}
	else
	{
		// Initialized left pseudocost
		return totaldeltal[i]/nodesl[i];
	}
}

double PseudocostR(int i)
{
	if(nodesr[i]==0)
	{
		// Uninitialized right pseudocost
		if(initpsr.size()==0)
		{
			// No initialized right pseudocost
			return 1;
		}
		else return avgpsr;
	}
	else
	{
		// Initialized left pseudocost
		return totaldeltar[i]/nodesr[i];
	}
}

bool compsc(s_l e1, s_l e2)
{
	return(e1.sc>e2.sc);
}

int ReliabilityChooseBranchingy(IloNumVarArray &y, IloRangeArray &zconst, IloCplex &cplex,double objparent, bool yes_z_rows)
{
	// Get scores
	IloNumArray yv(y.getEnv(),nodes);
	cplex.getValues(yv,y);
	vector<s_l> candlist;	
	s_l auxs;
	double auxv;
	int i;
	int ScoreMode = 1; // 1 = Product, 2 = Mu
	for(i=0;i<nodes;i++)
	{
		auxv = yv[i];
		if( (auxv>tolerance) && (auxv<1-tolerance) )
		{
			auxs.i = i;
			auxs.sc = Score(yv[i]*PseudocostL(i),(1-yv[i])*PseudocostR(i),1);
			candlist.push_back(auxs);
		}
	}
	sort(candlist.begin(),candlist.end(),compsc);
	vector<s_l>::iterator ss;
	ss = candlist.end()-1;
	if(ss->sc<1+tolerance)
	{
		// There is no pseudocost larger than 1.
		// Change to mu criterion instead of product.
		ScoreMode = 2;
		ss = candlist.begin();
		while(ss!=candlist.end())
		{
			i = ss->i;
			ss->sc = Score(yv[i]*PseudocostL(i),(1-yv[i])*PseudocostR(i),2);
			++ss;
		}
		sort(candlist.begin(),candlist.end(),compsc);
	}
	
	/* Choose the best among the reliable candidates */
	ss = candlist.begin();
	double best_val = -1;
	int best_i = -1;
	while(ss!=candlist.end())
	{
		i = ss->i;
		if ( (nodesl[i]>=reliab) && (nodesr[i]>=reliab) )
		{
			best_val = ss->sc;
			best_i = i;
			break;
		}
		++ss;
	}

	// Strong branching for some unreliable candidates
	int noimproveiter = 0;
	double auxvs,vall,valr;
	const char *bsname;
	IloCplex::BasisStatusArray yst(y.getEnv());
	IloCplex::BasisStatusArray rngst(y.getEnv());
	clock_t ttime;
	ss = candlist.begin();
	bool stronginitialized = false;
	while( (ss!=candlist.end()) && (noimproveiter<lambda) )
	{
		i = ss->i;
		if( (nodesl[i]<reliab) || (nodesr[i]<reliab) )
		{	
			totalstrong+=2;
			if(!stronginitialized)
			{
				// Set up information first time strong branching called
				stronginitialized = true;
				cplex.setParam(IloCplex::ItLim,75);
				
				
				if(yes_z_rows==false)
				{
					clock_t auxi_time=clock();
					++totalbasis;
					this_active_node->basis = totalbasis;
					bsname = Get_Basis_Name(totalbasis);
					cplex.writeBasis(bsname);
					write_basis_time+=(double)(clock()-auxi_time)/CLOCKS_PER_SEC;
				}
				else bsname = Get_Basis_Name(this_active_node->basis);

				cplex.getBasisStatuses(yst,y,rngst,zconst);
			}
			// Strong branching downwards
			cplex.setBasisStatuses(yst,y,rngst,zconst);
			ttime = clock();
			cplex.readBasis(bsname);
			strongb_readb_time+=(double)(clock()-ttime)/CLOCKS_PER_SEC;
			y[i].setBounds(0,0);
			ttime = clock();
			cplex.solve();
			strongb_solve_time+=(double)(clock()-ttime)/CLOCKS_PER_SEC;
			if(cplex.getStatus()!=IloAlgorithm::Infeasible)
			{
				vall = cplex.getObjValue() - objparent;
				totaldeltal[i]+= vall/yv[i];
				if(nodesl[i]==0) initpsl.push_back(i);
				++nodesl[i];
			}
			else vall = -2;
						
			// Strong branching upwards
			cplex.setBasisStatuses(yst,y,rngst,zconst);
			ttime = clock();
			cplex.readBasis(bsname);
			strongb_readb_time+=(double)(clock()-ttime)/CLOCKS_PER_SEC;
			y[i].setBounds(1,1);
			ttime = clock();
			cplex.solve();
			strongb_solve_time+=(double)(clock()-ttime)/CLOCKS_PER_SEC;
			if(cplex.getStatus()!=IloAlgorithm::Infeasible)
			{
				valr = cplex.getObjValue() - objparent;
				totaldeltar[i]+= valr/(1-yv[i]);
				if(nodesr[i]==0) initpsr.push_back(i);
				++nodesr[i];
			}
			else valr = -2;
					
			// Reset bound for y[i]
			y[i].setBounds(0,1);
			
			// Get strong branching score
			if( (vall>-tolerance) && (valr>-tolerance) )
			{
				// Both problems are feasible
				auxvs = Score(vall,valr,ScoreMode);
			}
			else if (vall>-tolerance)
			{
				// Right problem is unfeasible
				auxvs = Score(vall,vall,ScoreMode);
			}
			else
			{
				// Left problem is unfeasible
				auxvs = Score(valr,valr,ScoreMode);
			}

			if (auxvs>best_val+tolerance)
			{
				best_val = auxvs;
				best_i = i;
				if( (ss!=candlist.begin()) && (noimproveiter==lambda-1) )
				{
					// Increase lookahed step
					++lambda;
				}
				noimproveiter = 0;
			}
			else ++noimproveiter;
		}
		else ++noimproveiter;
		++ss;
	}
	
	if( (noimproveiter==lambda) && (lambda>lambdamin) )
	{		
		// Decrease lookahead step
		--lambda;
	}
	UpdateAvgPs();
	candlist.~vector();
	return best_i;
}

void Prune_Node(n_i *n_to_prune)
{
	n_i *parent_node = n_to_prune->parent_node;
	if (parent_node!=NULL)
	{
		if (n_to_prune->branch_value=0) parent_node->left_son = NULL;
		else parent_node->right_son = NULL;
		
		n_to_prune->parent_node = NULL;
		delete n_to_prune;

		--parent_node->active_children;
		if (parent_node->active_children==0) Prune_Node(parent_node);
	}
	else delete n_to_prune;
	return;
}

void Insert_in_List(n_i *n_to_insert)
{
	/* If the node cannot be pruned, it is added to the active node list */
	++active_nodes;
	a_n *aux = the_first_active_node;
	
	/* Best node search: lower bounds go first.
	   Should there be a tie, the newest node goes last. */
	while( (aux->next!=NULL) && (aux->the_info->lower_bound<n_to_insert->lower_bound+tolerance) )
	{
		aux = aux->next;
	}

	/* The first value has always a lesser (or equal) lower bound than the one in the node 
	   to insert. */
	if ( (aux->next==NULL) && (aux->the_info->lower_bound < n_to_insert->lower_bound+tolerance) )
	{
		aux->next = Create_a_n();
		aux->next->previous = aux;
		aux = aux->next;
		aux->next = NULL;
	}
	else
	{
		aux = aux->previous;
		a_n* aux2 = Create_a_n();
		aux2->previous = aux;
		aux2->next = aux->next;
		aux->next->previous = aux2;
		aux->next = aux2;
		aux = aux->next;
	}
	aux->the_info = n_to_insert;
	return;
}

void Set_Solver_Parameters(IloCplex cplex)
{
	cplex.setParam(IloCplex::RootAlg,2);
	cplex.setParam(IloCplex::PreInd,0);
	cplex.setParam(IloCplex::DPriInd,2);
	return;
}

int Enlarge_zdepths(IloNumVarArray2 &zz)
{
	int zs = zdepths.size();
	zdepths.resize(zs+1);
	zdepths[zs].resize(nodes);
	for(int i=0;i<nodes;i++) zdepths[zs][i] = zz[i].getSize();
	return zs;
}

void Use_RW_info(char *filename)
{
	FILE *data_file;
	fopen_s(&data_file,filename,"r");
	const int LINESIZE = 256;
	char buffer [LINESIZE + 1];
	double zvalue;
	int i,j,c,k;
	k=0;
	while(fgets (buffer, LINESIZE, data_file))
	{
		if(sscanf_s(buffer, "v %lf", &zvalue) == 1) 
		{
			incumbentis = true;
			if(zvalue<incumbent_value-tolerance) incumbent_value = zvalue;
			else return;
		}
		if(sscanf_s(buffer,"n %i",&nodes)==1) incumbent_x.resize(nodes);
		if(sscanf_s(buffer,"y %i", &j)==1)
		{
			incumbent_y[k] = j-1;
			++k;
		}
		if(sscanf_s(buffer,"x %d %d %d",&i,&j,&c)==3) incumbent_x[i-1] = j-1;
	}
}

void UpdatePseudocost(double parentobj, double childobj, bool kinship, double yval, int i)
{
	if(kinship)
	{
		// Right son
		totaldeltar[i]+= (childobj - parentobj)/(1-yval);
		if(nodesr[i]==0) initpsr.push_back(i);
		++nodesr[i];
	}
	else
	{
		// Left son
		totaldeltal[i]+= (childobj - parentobj)/yval;
		if(nodesl[i]==0) initpsl.push_back(i);
		++nodesl[i];
	}
}

void DeleteTree()
{
	while(the_first_active_node->next!=NULL)
	{
		a_n *aux_an;
		aux_an = the_first_active_node;
		the_first_active_node = the_first_active_node->next;
		the_first_active_node->previous = NULL;
		aux_an->next = NULL;
		this_active_node = aux_an->the_info;
		aux_an->the_info = NULL;
		Prune_Node(this_active_node);
		delete aux_an;
	}
	this_active_node = the_first_active_node->the_info;
	the_first_active_node->the_info = NULL;
	Prune_Node(this_active_node);
	delete(the_first_active_node);
	return;
}

void PrintSolInfo()
{
	myprintf("\n");
	myprintf("TOTAL NODES: %i\n",total_nodes);
	myprintf("LOWER BOUND AT ROOT: %i\n",(int)LB_root);
	myprintf("\n");
	myprintf("* CREATE DATA TIME: %.2lf\n",create_data_time);
	myprintf("* GENERATE MODEL TIME: %.2lf\n",generate_model_time);
	myprintf("* ADD CONSTRAINTS TIME: %.2lf\n",add_constraints_time);
	myprintf("* WRITE BASIS TIME: %.2lf\n",write_basis_time);
	myprintf("* READ BASIS TIME: %.2lf\n",read_basis_time);
	myprintf("* SOLVE MODEL TIME: %.2lf\n",solve_model_time);
	myprintf("\n");
	if(total_nodes>0)
	{
		myprintf("* CHOOSE BRANCHING Y: %.2lf\n",choose_y);
		myprintf(" STRONG BRANCHING - READ BASIS: %.2lf\n",strongb_readb_time);
		myprintf(" STRONG BRANCHING - SOLVE: %.2lf\n",strongb_solve_time);
		myprintf(" STRONG TIMES: %i\n",totalstrong);
		myprintf("\n");
	}
	myprintf("* IN ROOT %.2lf\n",root_time);
	myprintf("\n");
	myprintf("LONG DE ZDEPTHS: %i\n",(int)zdepths.size());
	myprintf("TOTAL BASIS: %i\n",totalbasis);
	myprintf("\n");
	return;
}

void PrintIncInfo()
{
	if(incumbentis)
	{
		double totalobj = 0;
		if(data_format==1)
		{
			for(int i=0;i<nodes;i++)
			{
				totalobj+=ctsp(i,incumbent_x[i]);
			}
		}
		else
		{
			for(int i=0;i<nodes;i++)
			{
				totalobj+=cdimacs(i,incumbent_x[i]);
			}
		}
		if(abs(totalobj-incumbent_value)<tolerance) myprintf("OBJECTIVE VALUE CHECKED: %lf\n",totalobj);
		else myprintf("PROBLEM WITH OBJECTIVE VALUE: CHECKED IS %lf AND INCUMBENT IS %lf\n",totalobj,incumbent_value);
		for(int i=0;i<p;i++)
		{
			myprintf("y: %i\n",incumbent_y[i]+1);
		}
		myprintf("\n");
		for(int i=0;i<nodes;i++)
		{
			myprintf("x: %i -> %i\n",i+1,incumbent_x[i]+1);
		}
	}
		return;
}

void FreeMemory()
{
	for(int i=0;i<nodes;i++)
	{
		Dv[i].~vector();
		for(unsigned int j=0;j<S[i].size();j++)
		{
			S[i][j].~vector();
		}
		S[i].~vector();
	}
	if(totalbasis>0) system("del *.bas");
	zdepths.~vector();
	if (RWiter==0) delete []G;
	if(data_format==1)
	{
		delete []x;
		delete []y;
	}
	else
	{
		cost.~vector();
	}
	Dv.~vector();
	S.~vector();
	totaldeltar.~vector();
	totaldeltal.~vector();
	nodesr.~vector();
	nodesl.~vector();
	return;
}

void CompleteProcesses()
{
	myprintf("ACTIVE NODES: %i\n",active_nodes);
	myprintf("TOTAL NODES: %i\n",total_nodes);
	myprintf("\n");
	if (totalbasis>0) DeleteTree();
	PrintSolInfo();
	PrintIncInfo();
	if(save_solution_info) fclose(solution_file);
	FreeMemory();
	return;
}