#include <ilcplex/ilocplex.h>
#include <ctime>
ILOSTLBEGIN

#include "global.h"
#include "auxiliar_functions.h"
#include "model_functions.h"
#include "root_node.h"
#include "general_node.h"

/* This version is only valid if costs are integer values */
   
int main (int argc, char *argv[])
{	
	time_t nowtime;
	time(&nowtime);
	printf("BEGIN AT %s\n",ctime(&nowtime));
		
	if(Read_Parameters(argc,argv)==false)
	{
		printf("ERROR: wrong command line.\n");
		printf("The structure is: z_reduced.exe <data_file> [-p p] [-b b] [-h h] [-d d][-s output_file]\n");
		printf("\n");
		printf("p = number of facilities to open\n");
		printf("b = upper bound for the optimal value\n");
		printf("h = apply h times Popstar heuristic (Resende-Werneck) before starting.\n");
		printf("output_file = file where the output information is saved.\n");
		printf("d = 1 if all the D[i][k] are generated at the begin, d = 0 othewise (default).\n");
		return 0;
	}
	if(save_solution_info)
	{
		if(fopen_s(&solution_file,solution_file_name,"w"))
		{
			printf("ERROR: impossible to generate output file.\n");
			exit(1);
		}
	}
		
	clock_t aux_time;	
	incumbent_y.resize(p);
	
	// Resende-Werneck heuristic (popstar)
	char orden[65];
	char rwfile[20];
	for(int h=0;h<RWiter;h++)	
	{
		strcpy_s(rwfile,argv[1]);
		strcat_s(rwfile,"rw");
		std::string s;
		std::stringstream out;
		out << h;
		s = out.str();
		strcat_s(rwfile,s.c_str());
		sprintf_s(orden,"mypop %s -p %i -output %s",argv[1],p,rwfile);
		aux_time = clock();
		system(orden);
		Use_RW_info(rwfile);
		heur_time += (double)(clock()-aux_time)/CLOCKS_PER_SEC;
	}
	/* Generate initial data structures */
	start_time = clock();
	char *data_file_name;
	data_file_name = argv[1];
	if (!Read_Data(data_file_name))
	{
		myprintf("ERROR: file %s not found.\n",data_file_name);
		if(save_solution_info) 	fclose(solution_file);
		return 0;
	}
	try{
		if (p>nodes)
		{
			myprintf("ERROR: p must be smaller than the number of facilities %i\n",nodes);
			return 0;
		}
		printf("Read data time: %lf\n",(double)(clock()-start_time)/CLOCKS_PER_SEC);
		if(RWiter==0) incumbent_x.resize(nodes);
		aux_time = clock();
		if(RWiter==0) Generate_D_sdznoh();
		else Generate_D_sdzh();
		//printf("Generate D time: %lf\n",(double)(clock()-aux_time)/CLOCKS_PER_SEC);
		Start_S();
	}
	catch(const bad_alloc)
	{
		cout << "ERROR: out of memory while generating D and S." << endl;
		return 0;
	}
    create_data_time =(double) (clock() - start_time)/CLOCKS_PER_SEC;

	time(&nowtime);
	myprintf("INICIO ROOT %s\n",ctime(&nowtime));
	printf("INICIO ROOT %s\n",ctime(&nowtime));
	
	/* Initialize bounds */
	/* Minimization problem */
	initial_upper_bound = incumbent_value;
	printf("IUB: %lf\n",initial_upper_bound); // Initial Upper Bound
	/* ROOT NODE */
	active_nodes = 0;
	double rtime=clock();
	Solve_Root_Node();
	time(&nowtime);
	myprintf("OUT OF ROOT %s\n",ctime(&nowtime));
	printf("OUT OF ROOT %s\n",ctime(&nowtime));
	printf("\n");
	root_time = (double)(clock()-rtime)/CLOCKS_PER_SEC;
	total_nodes = 1;
	
	/* Solve the tree */
	double running_time = double(clock()-start_time)/CLOCKS_PER_SEC;
	while ( (active_nodes>0) && (running_time<time_limit) )
	{
		/* Point the father node */
		this_active_node = the_first_active_node->the_info;
		if (bestLB>incumbent_value-tolerance)
		{
			/* Optimal reached.
			 Delete the remaining tree */
			while(the_first_active_node->next!=NULL)
			{
				a_n *aux_an;
				aux_an = the_first_active_node;
				the_first_active_node = the_first_active_node->next;
				the_first_active_node->previous = NULL;
				aux_an->next = NULL;
				this_active_node = aux_an->the_info;
				aux_an->the_info = NULL;
				Prune_Node(this_active_node);
				delete aux_an;
			}
			this_active_node = the_first_active_node->the_info;
			the_first_active_node->the_info = NULL;
			Prune_Node(this_active_node);
			delete the_first_active_node;
			active_nodes = 0;
			break;
		}
		else
		{
			/* Solve left son node */
			++total_nodes;
			/* Create left son */
			this_active_node->left_son = Create_n_i();
			this_active_node->left_son->parent_node = this_active_node;
			/* We move to the left son */
			this_active_node = this_active_node->left_son;
			this_active_node->branch_value = 0;
			this_active_node->where_zdepths = this_active_node->parent_node->where_zdepths;
			this_active_node->left_son = NULL;
			this_active_node->right_son = NULL;
			Solve_General_Node();
						
			/* Solve right son node */
			++total_nodes;
			/* Point the father node */
			this_active_node = the_first_active_node->the_info;
			/* Create right son */
			this_active_node->right_son = Create_n_i();
			this_active_node->right_son->parent_node = this_active_node;
			/* We move to the right son */
			this_active_node = this_active_node->right_son;
			this_active_node->branch_value = 1;
			this_active_node->where_zdepths = this_active_node->parent_node->where_zdepths;
			this_active_node->left_son = NULL;
			this_active_node->right_son = NULL;
			Solve_General_Node();
		}	
		--active_nodes;
		
		/* Remove parent node from the list*/
		/* Since the_first_active_node is the most promising (smallest lower bound),
		 its two children cannot have a more promosing value */
		if (active_nodes>0)
		{
			a_n *aux_an;
			aux_an = the_first_active_node;
			the_first_active_node = the_first_active_node->next;
			the_first_active_node->previous = NULL;
			aux_an->next = NULL;
			delete aux_an;
			if(bestLB<incumbent_value-tolerance)
			{
				bestLB = ceil(the_first_active_node->the_info->lower_bound);
			}
		}
		else
		{
			this_active_node = the_first_active_node->the_info;
			the_first_active_node->the_info = NULL;
			Prune_Node(this_active_node);
			delete the_first_active_node;
		}
		running_time = (double)(clock()- start_time)/CLOCKS_PER_SEC;
	}
	time(&nowtime);
	printf("FIN S %s\n",ctime(&nowtime));
	
	myprintf("Total running time: %.0lf\n",running_time);
	
	if(data_format==2)
	{
		running_time+= external_generation_time;
		myprintf("\n");
		myprintf("External data generation time: %.0lf\n",external_generation_time);
		myprintf("Full total running time: %.0lf\n",running_time);
	}
	if(RW)
	{
		myprintf("\n");
		myprintf("Time in heuristics: %.0lf\n",heur_time);
		myprintf("Total running time including heuristic time: %.0lf\n",running_time+heur_time);
		myprintf("RW was applied %i time(s).\n",RWiter);
		if(RWiter>1)
		{
			double avhtime = heur_time/RWiter;
			myprintf("Average time in heuristics: %.0lf\n",avhtime);
			myprintf("Average total running time including heuristic time: %.0lf\n",running_time+avhtime);
		}
	}

	myprintf("\n");
	myprintf("SDZ: %i\n",sdz);
	if(total_nodes>1) myprintf("REL: %i  LAMBDA0 %i\n",reliab,lambda0);
	myprintf("IUB: %lf\n",initial_upper_bound);
	myprintf("\n");
	if (running_time<time_limit) myprintf("STATUS: OPTIMAL VALUE = %lf\n",incumbent_value);
	else
	{
		myprintf("STATUS: TIME LIMIT REACHED WITH %i ACTIVE NODES.\n",active_nodes);
		myprintf("\n");
		Show_Partial_Solution();
		DeleteTree();
	}
	PrintSolInfo();

	PrintIncInfo();
	if(save_solution_info) fclose(solution_file);
		
	FreeMemory();
	return 0;
}
